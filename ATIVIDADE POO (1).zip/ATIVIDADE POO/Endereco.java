package AtividadePOO;
//Guilherme De Queiroz Caixeta//0019429//

public class Endereco {
	
	     String rua;
	     int logradouro;

		public String toString() {
	        return "Endereco{" +
	               "rua='" + rua + '\'' +
	               " logradouro='" + logradouro + '\'' +
	               '}';
	    }
	}
	