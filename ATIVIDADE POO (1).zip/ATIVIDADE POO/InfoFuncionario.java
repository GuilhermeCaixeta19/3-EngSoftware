package AtividadePOO;
//Guilherme De Queiroz Caixeta//0019429//
public class InfoFuncionario {
	
	public static void main(String[] args) {
	
		Funcionario info = new Funcionario();
		info.idade =40;
		info.Matricula = 2306;
		info.nome = "Lebron James";
		info.salario = 10000.0;
		info.endereco = "rua 23, quadra 06, casa 01 ";
		info.bonificar(10.0);
		 
		System.out.println(info);
		 
		Endereco info2 = new Endereco();
		info2.logradouro = 01;
		info2.rua = "rua 23";
		
		System.out.println(info2);
		
		Telefone info3 = new Telefone();
		info3.numero = 996230401;
		info3.tipo = "Celular";
		
	    System.out.println(info3);
	    
	    if (info.idade > 65) {
	    	System.out.println("O funcionario pode se aposentar");
	    }
	    else {
	    	System.out.println("O funcionario não pode se aposentar");
	    	
	    }
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
