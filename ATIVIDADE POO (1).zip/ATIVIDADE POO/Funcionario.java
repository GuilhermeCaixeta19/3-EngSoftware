package AtividadePOO;
//Guilherme De Queiroz Caixeta//0019429//
public class Funcionario {
      
		
			 String nome;
			 int Matricula;
			 int idade;
			 double salario;
			 String endereco;
			 int  telefone;


			   boolean verificarIdadeAposentadoria() {
			        return this.idade > 65;
			    }

			    public void bonificar(double valor) {
			        salario =salario + valor;
			    }

			  
			    public String toString() {
			        return "Funcionario [nome=" + nome +", matricula=" + Matricula +",idade" + idade +",salario=" + salario +"]";
			               
			    }
			    
			   
		
	}


