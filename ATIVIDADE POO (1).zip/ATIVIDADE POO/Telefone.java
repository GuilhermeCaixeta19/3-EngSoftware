package AtividadePOO;
//Guilherme De Queiroz Caixeta//0019429//

public class Telefone {
	
	    int numero;
	    String tipo; 

	  
	    public String toString() {
	        return "Telefone[numero=" + numero + ", tipo=" + tipo + "]";
	      
	}
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


