package AtividadeMatematica;


class Divisao extends OperacoesMatematica {
	
    @Override
    public double calcular(double x, double y) {
        return x / y;
    }
}

