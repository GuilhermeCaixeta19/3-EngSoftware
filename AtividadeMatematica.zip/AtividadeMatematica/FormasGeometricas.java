package AtividadeMatematica;

public interface FormasGeometricas {
	
	 double calcularArea();
	    double calcularPerimetro();
	}



