package AtividadeMatematica;
//LETICIA AUGUSTO DOS SANTOS
// MATRICULA 0018502

public abstract class OperacoesMatematica {
	
	public abstract double calcular(double x, double y);
	
}
	

