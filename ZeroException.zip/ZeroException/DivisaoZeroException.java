package ZeroException;


class DivisaoPorZeroException extends Exception {
    public DivisaoPorZeroException(String message) {
        super(message);
 

 }
}
