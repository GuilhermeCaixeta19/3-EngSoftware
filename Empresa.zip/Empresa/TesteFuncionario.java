package Empresa;

public class TesteFuncionario {

	public static void main(String[] args) {
		
		FuncionarioEmpresa funcionarioEmpresa = new FuncionarioEmpresa();
		
		funcionarioEmpresa.setMatricula(520);
		funcionarioEmpresa.setNome("Guilherme");
		funcionarioEmpresa.setIdade(18);
		funcionarioEmpresa.setCargo("Estagiário BKO");
		funcionarioEmpresa.setSalario(700.0);
		
		System.out.println(funcionarioEmpresa);
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
